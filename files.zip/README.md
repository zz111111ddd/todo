# todo_cli

Небольшой менеджер задач для командной строки. Только стандартная библиотека Python 3.8+.

## Использование

```bash
python todo.py add Купить молоко
python todo.py list
python todo.py list --pending
python todo.py done 1
python todo.py remove 1
```

Данные хранятся в `~/.todo_cli.json`; другой файл можно указать через `--db путь`.

## Тесты

```bash
python -m unittest -v
```
