import tempfile
import unittest
from pathlib import Path

from todo import TodoStore, main


class TodoStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "db.json"
        self.store = TodoStore(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def test_add_assigns_incrementing_ids(self):
        self.assertEqual(self.store.add("a").id, 1)
        self.assertEqual(self.store.add("b").id, 2)

    def test_empty_title_rejected(self):
        with self.assertRaises(ValueError):
            self.store.add("   ")

    def test_complete_and_filter(self):
        self.store.add("a")
        self.store.add("b")
        self.store.complete(1)
        self.assertEqual([t.id for t in self.store.list(show_all=False)], [2])

    def test_remove_missing_raises(self):
        with self.assertRaises(KeyError):
            self.store.remove(42)

    def test_data_persists_between_instances(self):
        self.store.add("сохранить меня")
        again = TodoStore(self.db)
        self.assertEqual(again.list()[0].title, "сохранить меня")

    def test_cli_returns_error_code(self):
        self.assertEqual(main(["--db", str(self.db), "done", "99"]), 1)


if __name__ == "__main__":
    unittest.main()
